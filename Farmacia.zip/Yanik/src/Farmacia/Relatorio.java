package Farmacia;

import java.util.Vector;

public class Relatorio {
	 public static void produtosMaisVendidos(Vector<Produto> Armazem) {

	        if (Armazem.isEmpty()) {
	            System.out.println("Sem produtos.");
	            return;
	        }

	        System.out.println("=== PRODUTOS MAIS VENDIDOS ===");

	        for (Produto p : Armazem) {
	            if (p.getQuantidadeVendida() > 0) {
	                System.out.println(
	                    p.getNome() + " | Vendidos: " + p.getQuantidadeVendida()
	                );
	            }
	        }
	    }
	 
	 public static void produtosStockBaixo(Vector<Produto> Armazem) {

	        System.out.println("=== PRODUTOS COM STOCK BAIXO ===");

	        for (Produto p : Armazem) {
	            if (p.getQuantidadeStock() <= 5) {
	                System.out.println(
	                    p.getNome() + " | Stock: " + p.getQuantidadeStock()
	                );
	            }
	        }
	    }
}
