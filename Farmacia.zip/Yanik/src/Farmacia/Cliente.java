package Farmacia;
import java.util.Vector;
import java.util.Scanner;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.File;
import java.util.StringTokenizer;
public class Cliente {
	private String nome;
	private int telefone;
	private Vector<Double> compras = new Vector<>();
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public int getTelefone() {
		return telefone;
	}
	
	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	
	public static Vector<Cliente> carregarClientes(String caminho) {

	    Vector<Cliente> clientes = new Vector<>();

	    try {

	        Scanner input = new Scanner(new File(caminho));

	        while (input.hasNextLine()) {

	            String linha = input.nextLine();

	            StringTokenizer st =
	                new StringTokenizer(linha, ";");

	            Cliente c = new Cliente();

	            c.setNome(st.nextToken());
	            c.setTelefone(
	                Integer.parseInt(st.nextToken())
	            );

	            clientes.add(c);
	        }

	        input.close();

	    } catch (Exception e) {
	        System.out.println(
	            "Ficheiro de clientes não encontrado."
	        );
	    }

	    return clientes;
	}
	
	public static void guardarClientes(Vector<Cliente> clientes, String caminho) {

	    try {
	        BufferedWriter bw = new BufferedWriter(new FileWriter(caminho));

	        for (Cliente c : clientes) {

	            bw.write(
	                c.getNome() + ";" +
	                c.getTelefone()
	            );

	            bw.newLine();
	        }

	        bw.close();

	    } catch (Exception e) {
	        System.out.println("Erro ao guardar clientes!");
	    }
	}
	
	public static String criarCliente(Vector<Cliente> cliente) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Insira o nome: ");
		String nome = input.next();
		System.out.print("Insira o número de Telefone: ");
		int telefone = input.nextInt();
		
		Cliente c = new Cliente();
		c.setNome(nome);
		c.setTelefone(telefone);
		
		cliente.add(c);
		guardarClientes(cliente, "clientes.txt");
		return "Cliente criado!";
	}
	
	public static String actualizarCliente(Vector<Cliente> cliente) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Insira o nome: ");
		String nome = input.next();
		
		boolean encontra = false;
		int indice = 0;
		for(int i = 0; i < cliente.size(); i++) {
			if(cliente.get(i).getNome().equalsIgnoreCase(nome)) {
				encontra = true;
				indice = i;
			}
		}
		
		if(encontra) {
			System.out.println("1 - Actualizar nome");
			System.out.println("2 - Actualizar número de Telefone");
			System.out.print("Insira a opção: ");
			int opcao = input.nextInt();
			
			switch(opcao) {
			case 1:
				System.out.print("Insira o novo nome: ");
				String nome2 = input.next();
				cliente.get(indice).setNome(nome2);
				break;
			case 2: 
				System.out.print("Insira o novo número de Telefone: ");
				int telefone = input.nextInt();
				cliente.get(indice).setTelefone(telefone);
				break;
			default:
				System.out.println("Opção Inválida!");
			}
			guardarClientes(cliente, "clientes.txt");
			return "Cleinte actualizado com sucesso!";
		} else {
			return "Cliente não encontrado!";
		}
	}
	
	public static String removerCliente(Vector<Cliente> cliente) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Insira o nome: ");
		String nome = input.next();
		
		boolean encontra = false;
		int indice = 0;
		for(int i = 0; i < cliente.size(); i++) {
			if(cliente.get(i).getNome().equalsIgnoreCase(nome)) {
				cliente.remove(i);
				guardarClientes(cliente, "clientes.txt");
				return "Cliente removido com  sucesso!";
			}
		}
		return "Cliente não encontrado!";
	}
	
	public static boolean pesquisarCliente(Vector<Cliente> cliente) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Insira o nome: ");
		String nome = input.next();
		System.out.print("Insira o número de telefone: ");
		int telefone = input.nextInt();
		
		boolean encontra = false;
		for(int i = 0; i < cliente.size(); i++) {
			if(cliente.get(i).getNome().equalsIgnoreCase(nome) || (cliente.get(i).getTelefone() == telefone)) {
				encontra = true;
				return encontra;
			} 
		}
		return encontra;
	}
	
	public void adicionarCompra(double valor) {
	    compras.add(valor);
	}
	
	public double totalContaCorrente() {

	    double total = 0;

	    for (double v : compras) {
	        total += v;
	    }

	    return total;
	}
	
	public static void verContaCorrente(Vector<Cliente> clientes) {

	    Scanner input = new Scanner(System.in);

	    System.out.print("Insira o nome do cliente: ");
	    String nome = input.next();

	    for (Cliente c : clientes) {

	        if (c.getNome().equalsIgnoreCase(nome)) {

	            System.out.println("=== CONTA CORRENTE ===");
	            System.out.println("Cliente: " + c.getNome());

	            double total = 0;

	            for (double v : c.compras) {
	                System.out.println("Compra: " + v);
	                total += v;
	            }

	            System.out.println("----------------------");
	            System.out.println("TOTAL GASTO: " + total);

	            return;
	        }
	    }

	    System.out.println("Cliente não encontrado!");
	}
	
	public static void listarClientes(Vector<Cliente> cliente) {

	    System.out.println("=== LISTA DE CLIENTES ===");

	    for (Cliente c : cliente) {
	        System.out.println("Nome: " + c.getNome() +
	                           " | Telefone: " + c.getTelefone());
	    }
	}
}
