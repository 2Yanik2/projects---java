package Farmacia;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Vector;
import java.util.Scanner;
public class Produto {
    private int codigo;
    private String nome;
    private double preco;
    private int quantidadeStock;
    private int quantidadeVendida;
    
    

    public int getQuantidadeVendida() {
		return quantidadeVendida;
	}

	public void setQuantidadeVendida(int quantidadeVendida) {
		this.quantidadeVendida = quantidadeVendida;
	}

	public Produto() {
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getQuantidadeStock() {
        return quantidadeStock;
    }

    public void setQuantidadeStock(int quantidadeStock) {
        if (quantidadeStock < 0) {
            System.out.println("Erro! Stock não pode ser negativo");
        } else {
            this.quantidadeStock = quantidadeStock;
        }
    }

    public static void guardarProdutos(Vector<Produto> Armazem, String caminho) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(caminho));
            for (int i = 0; i < Armazem.size(); i++) {
                Produto p = Armazem.get(i);
                bw.write(p.getNome() + ";" + p.getCodigo() + ";" + p.getPreco() + ";" + p.getQuantidadeStock());
                bw.newLine();
            }
            bw.close();
        } catch (Exception e) {
            System.out.println("Erro ao guardar produtos!");
        }
    }

    public static String criarProduto(Vector<Produto> Armazem) {
        Scanner input = new Scanner(System.in);

        System.out.print("Insira o nome: ");
        String nome = input.next();
        System.out.print("Insira o código: ");
        int codigo = input.nextInt();

        boolean encontra = false;
        for (Produto p : Armazem) {
            if (p.getCodigo() == codigo) {
                encontra = true;
                break;
            }
        }

        if (encontra == false) {
            System.out.print("Insira o preço: ");
            double preco = input.nextDouble();
            System.out.print("Insira a quantidade: ");
            int quantidade = input.nextInt();

            Produto p = new Produto();
            p.setNome(nome);
            p.setCodigo(codigo);
            p.setPreco(preco);
            p.setQuantidadeStock(quantidade);

            Armazem.add(p);

            guardarProdutos(Armazem, "produtos.txt");

            return "Produto Criado!";
        } else {
            return "Código já existente!";
        }
    }

    public static String atualizarProduto(Vector<Produto> Armazem) {
        Scanner input = new Scanner(System.in);
        boolean encontra = false;
        int indice = 0;

        System.out.print("Insira o código do produto que pretende alterar: ");
        int codigo2 = input.nextInt();

        for (int i = 0; i < Armazem.size(); i++) {
            if (Armazem.get(i).getCodigo() == codigo2) {
                encontra = true;
                indice = i;
                break;
            }
        }

        if (encontra == true) {
            System.out.println("1 - Atualizar nome");
            System.out.println("2 - Atualizar código");
            System.out.println("3 - Atualizar preço");
            System.out.println("4 - Atualizar stock");
            System.out.print("Insira a opção: ");
            int opcao = input.nextInt();

            switch (opcao) {
                case 1:
                    System.out.print("Insira o novo nome: ");
                    String nome2 = input.next();
                    Armazem.get(indice).setNome(nome2);
                    break;
                case 2:
                    System.out.print("Insira o novo código: ");
                    int codigo = input.nextInt();
                    Armazem.get(indice).setCodigo(codigo);
                    break;
                case 3:
                    System.out.print("Insira o novo preço: ");
                    double preco = input.nextDouble();
                    Armazem.get(indice).setPreco(preco);
                    break;
                case 4:
                    System.out.print("Insira o novo stock: ");
                    int stock = input.nextInt();
                    Armazem.get(indice).setQuantidadeStock(stock);
                    break;
                default:
                    System.out.println("Opção inválida!");
            }
            guardarProdutos(Armazem, "produtos.txt");
            return "Produto actualizado com sucesso!";
        } else {
            return "Produto não encontrado!";
        }
    }

    public static String removerProduto(Vector<Produto> Armazem) {
        Scanner input = new Scanner(System.in);
        System.out.print("Insira o código do produto a remover: ");
        int codigo = input.nextInt();

        for (int i = 0; i < Armazem.size(); i++) {
            if (Armazem.get(i).getCodigo() == codigo) {
                Armazem.remove(i);
                guardarProdutos(Armazem, "produtos.txt");
                return "Produto removido com sucesso!";
            }
        }
        return "Produto não encontrado!";
    }
    
    
    public static double venderProduto(Vector<Produto> Armazem, int codigo, int quantidade) {

        double IVA = 17;

        for (Produto p : Armazem) {

            if (p.getCodigo() == codigo) {

                if (quantidade <= 0) {
                    System.out.println("Quantidade inválida!");
                    return -1;
                }

                if (p.getQuantidadeStock() >= quantidade) {

                    p.setQuantidadeStock(p.getQuantidadeStock() - quantidade);
                    p.setQuantidadeVendida(p.getQuantidadeVendida() + quantidade);

                    double subtotal = p.getPreco() * quantidade;
                    double total = subtotal + (subtotal * IVA / 100);

                    guardarProdutos(Armazem, "produtos.txt");

                    System.out.println("Venda efetuada com sucesso!");
                    System.out.println("Produto: " + p.getNome());
                    System.out.println("Total com IVA: " + total);

                    return total;

                } else {
                    System.out.println("Stock insuficiente!");
                    return -1;
                }
            }
        }

        System.out.println("Produto não encontrado.");
        return -1;
    }
   
    
   
}
