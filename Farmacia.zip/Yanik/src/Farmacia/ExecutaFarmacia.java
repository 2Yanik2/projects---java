package Farmacia;

import java.util.Vector;
import java.io.File;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ExecutaFarmacia {
    public static void main(String[] args) {
        Vector<Produto> Armazem = new Vector<>();
        Vector<Cliente> cliente = Cliente.carregarClientes("clientes.txt");
        
        String caminhoFicheiro = "produtos.txt";
        File ficheiro = new File(caminhoFicheiro);
        String linha = "";

        try {
            Scanner input = new Scanner(ficheiro);
            while (input.hasNextLine()) {
                linha = input.nextLine();
                StringTokenizer st = new StringTokenizer(linha, ";");
                String nome = st.nextToken();
                int codigo = Integer.parseInt(st.nextToken());
                double preco = Double.parseDouble(st.nextToken());
                int quantidade = Integer.parseInt(st.nextToken());

                Produto p = new Produto();
                p.setCodigo(codigo);
                p.setNome(nome);
                p.setPreco(preco);
                p.setQuantidadeStock(quantidade);

                Armazem.add(p);
            }
            input.close();
        } catch (Exception e) {
            System.out.println("Ficheiro de produtos não encontrado.");
        }

        Scanner input = new Scanner(System.in);
        int opcao3;

        do {
            System.out.println("=== MENU PRINCIPAL ===");
            System.out.println("1 - Produto");
            System.out.println("2 - Cliente");
            System.out.println("3 - Relatório");
            System.out.print("Insira a opção: ");
            int opcao = input.nextInt();

            switch (opcao) {

                case 1: { 
                    int opcaoProduto;
                    do {
                        System.out.println("=== PRODUTO ===");
                        System.out.println("1 - Criar Produto");
                        System.out.println("2 - Atualizar Produto");
                        System.out.println("3 - Remover Produto");
                        System.out.println("4 - Vender Produto");
                        System.out.print("Insira a opção: ");
                        opcaoProduto = input.nextInt();

                        switch (opcaoProduto) {
                            case 1:
                                System.out.println(Produto.criarProduto(Armazem));
                                break;
                            case 2:
                                System.out.println(Produto.atualizarProduto(Armazem));
                                break;
                            case 3:
                                System.out.println(Produto.removerProduto(Armazem));
                                break;
                            case 4: {
                                System.out.print("Nome do cliente: ");
                                String nomeCliente = input.next();

                                Cliente clienteEncontrado = null;
                                for (Cliente c : cliente) {
                                    if (c.getNome().equalsIgnoreCase(nomeCliente)) {
                                        clienteEncontrado = c;
                                        break;
                                    }
                                }

                                if (clienteEncontrado == null) {
                                    System.out.println("Cliente não encontrado!");
                                    break;
                                }

                                System.out.print("Insira o Código do Produto: ");
                                int codigo = input.nextInt();
                                System.out.print("Quantidade: ");
                                int quantidade = input.nextInt();

                                double total = Produto.venderProduto(Armazem, codigo, quantidade);
                                if (total > 0) {
                                    clienteEncontrado.adicionarCompra(total);
                                    System.out.println("Venda registada na conta do cliente!");
                                }
                                break;
                            }
                            default:
                                System.out.println("Opção inválida.");
                        }

                        if (opcaoProduto != 0) {
                            System.out.print("Deseja continuar no menu Produto? (1 - Sim / 2 - Não): ");
                            opcaoProduto = input.nextInt() == 1 ? 1 : 0;
                        }

                    } while (opcaoProduto != 0);
                    break;
                }

                case 2: {
                    int opcaoCliente;
                    do {
                        System.out.println("=== CLIENTE ===");
                        System.out.println("1 - Criar Cliente");
                        System.out.println("2 - Actualizar Cliente");
                        System.out.println("3 - Remover Cliente");
                        System.out.println("4 - Ver Conta do Cliente");
                        System.out.println("5 - Listar Clientes");
                        System.out.print("Insira a opção: ");
                        opcaoCliente = input.nextInt();

                        switch (opcaoCliente) {
                            case 1:
                                System.out.println(Cliente.criarCliente(cliente));
                                break;
                            case 2:
                                System.out.println(Cliente.actualizarCliente(cliente));
                                break;
                            case 3:
                                System.out.println(Cliente.removerCliente(cliente));
                                break;
                            case 4:
                                Cliente.verContaCorrente(cliente);
                                break;
                            case 5:
                                Cliente.listarClientes(cliente);
                                break;
                            default:
                                System.out.println("Opção inválida.");
                        }

                        if (opcaoCliente != 0) {
                            System.out.print("Deseja continuar no menu Cliente? (1 - Sim / 2 - Não): ");
                            opcaoCliente = input.nextInt() == 1 ? 1 : 0;
                        }

                    } while (opcaoCliente != 0);
                    break;
                }

                case 3: { 
                    int opcaoRelatorio;
                    do {
                        System.out.println("=== RELATÓRIO ===");
                        System.out.println("1 - Produtos mais vendidos");
                        System.out.println("2 - Produtos com stock baixo");
                        System.out.print("Insira a opção: ");
                        opcaoRelatorio = input.nextInt();

                        switch (opcaoRelatorio) {
                            case 1:
                                Relatorio.produtosMaisVendidos(Armazem);
                                break;
                            case 2:
                                Relatorio.produtosStockBaixo(Armazem);
                                break;
                            default:
                                System.out.println("Opção inválida.");
                        }

                        if (opcaoRelatorio != 0) {
                            System.out.print("Deseja continuar no menu Relatório? (1 - Sim / 2 - Não): ");
                            opcaoRelatorio = input.nextInt() == 1 ? 1 : 0;
                        }

                    } while (opcaoRelatorio != 0);
                    break;
                }

                default:
                    System.out.println("Opção inválida.");
            }

            System.out.print("Deseja continuar no menu principal? (1 - Sim / 2 - Não): ");
            opcao3 = input.nextInt();

        } while (opcao3 != 2);

        System.out.println("Farmácia Fechada!");
    }
}